letter="Dear Yukti! This python course is Nice. Thanks!"
print(letter)
formatted_letter=("Dear Yukti!\n\t This python course is Nice.\nThanks!")
print(formatted_letter)