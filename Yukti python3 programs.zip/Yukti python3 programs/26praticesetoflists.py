# PRACTICE SET 1ST QUESTION
F1=input("enter 1 fruit : ")
F2=input("enter 2 fruit : ")
F3=input("enter 3 fruit : ")
F4=input("enter 4 fruit : ")
F5=input("enter 5 fruit : ")
F6=input("enter 6 fruit : ")
F7=input("enter 7 fruit : ")
fruits=["7 FRUITS ARE",F1,F2,F3,F4,F5,F6,F7]
print(fruits)


# PRACTICE SET 2ND QUESTION
a=int(input("ENTER MARKS OF STUDENT 1 : ")) #WE USED (INT) SO IT MAY NOT PRINT IN STRING
b=int(input("ENTER MARKS OF STUDENT 2 : "))
c=int(input("ENTER MARKS OF STUDENT 3 : "))
d=int(input("ENTER MARKS OF STUDENT 4 : "))
e=int(input("ENTER MARKS OF STUDENT 5 : "))
f=int(input("ENTER MARKS OF STUDENT 6 : "))

mylist=[a,b,c,d,e,f]
mylist.sort()
print(mylist)

# PRACTICE SET 3RD QUESTION
# y=(1,2,3,4,5)
# y[1]=8
# print(y)    # WILL THROW ERROR


#PRACTICE SET 4TH QUESTION
y=[2,4,6,8]
print(y[0] + y[1] + y[2] + y[3])
print(sum(y))

#PRACTICE SET 5TH QUESTION
R=[7,0,8,0,0,9]
print(R.count(0))
