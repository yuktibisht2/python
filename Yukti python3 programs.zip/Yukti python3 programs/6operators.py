###########ARITHMETIC OPERATORS###################
a=2
b=5
print("THE VALUE OF A IS", a+b)
print("THE VALUE OF A IS", a-b)
print("THE VALUE OF A IS", a*b)
print("THE VALUE OF A IS", a/b)
###############ASSIGNMENT OPERATOR#####################
a=5
a+=2
a*=2
a/=2
print("VALUE IS",(a))
################COMPARISON OPERATOR######################
a=(7>3)
print(a)
b=(7<3)
print(b)
c=(9==9)
print(c)
d=(6!=9)
print(d)
###################LOGICAL OPERATOR################
bool1=True
bool2=False
print("The value of bool1 AND bool2 is", (bool1 and bool2))
print("The value of bool1 OR bool2 is", (bool1 or bool2))
print("The value of bool1 NOT bool2 is", (not bool2))


