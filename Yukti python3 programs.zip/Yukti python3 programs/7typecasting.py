#############    INT TO FLOAT       ########################
a=456
a=float(a)
print(a+8)
print(type(a))
############    FLOAT TO INT        ######################
b=45.0
b=int(b)
print(b+8)
print(type(b))
#############   STRING TO INT      #######################
c="99"
c=int(c)
print(c+1)
print(type(c))
#############   STRING TO FLOAT     ########################
d="99"
d=(float(d))
print(d+1)
print(type(d))
##############  INT TO STRING       #######################
e=450
e=str(e+1)
print(e)
print(type(e))
##############  FLOAT TO STRING       #######################
f=456.5
f=str(f+1)
print(f)
print(type(f))
