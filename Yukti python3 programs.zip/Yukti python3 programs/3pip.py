
from playsound import playsound
playsound('C:\Yukti python3 programs\song.mp3')



