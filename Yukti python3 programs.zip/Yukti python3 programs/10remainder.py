a=input("ENTER NO ")
b=2
print(b)

a=float(a)
b=float(b)
c=a%2
print("THE VALUE AFTER DIVIDING A BY B IS ",c)
print(type(a))
print(type(b))