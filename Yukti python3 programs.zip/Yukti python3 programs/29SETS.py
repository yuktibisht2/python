a={1,2,3,1,2} #WILL PRINT ONLY 1,2,3 as it does not count repititive elements.
print(a)
print(type(a))   #TYPE IS "SET"


#empty dictionary
a={}
print(type(a))

#empty set
b=set()
print(type(b))