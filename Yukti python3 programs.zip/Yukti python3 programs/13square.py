a=input("ENTER NO : ")
a=int(a)
sq=a*a
print("SQUARE OF GIVEN NO IS",sq )