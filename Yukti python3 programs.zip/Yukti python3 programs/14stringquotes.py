a="yukti's"
b='yukti"s'
c='''yukti"s'''
d="yukti'''s"
print(a)
print(b)
print(c)
print(d)