a=["YUKTI","BISHT","APRIL", 23]
print(a[0:3])

print(a[0:1]) 


# using negative slicing
print(a[-4:])

print(a[-4:-1])

print(a[-1:-4])    #how to print this in reverse order?