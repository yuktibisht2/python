a=input("ENTER ANY NUMBER : ")
b=input("ENTER ANY NUMBER : ")
a=float(a)
b=float(b)
avg=(a+b)/2
print("average of given no is", avg)
