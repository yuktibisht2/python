# CREATING A TUPLE USING ()
t=(1,2,3,4,5,1,1,1,3,3,2)  #WILL RETURN NO OF TIMES 1 OCCURS IN a.
print(t.count(1))
print(t.index(3))



t=(1,2,3,4,5,1,1,1,3,3,2)   #RETURNS THE INDEX OF FIRST OCCURENCE OF 3 IN a.
print(t.index(5))
