# YUKTI BISHT
#LOCATION-TEHRI GARHWAL
#SOURCE-CODE WITH HARRY
import os
print(os.listdir())
#two different ways
import os
print(os.path)
