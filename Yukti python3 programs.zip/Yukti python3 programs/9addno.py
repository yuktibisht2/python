############   USER INPUT  ################
a=input("ENTER NO ")
b=input("ENTER ANOTHER NO ")
a=int(a)
b=int(b)
sum=a+b
print("SUM OF TWO NO IS",sum )
##########    ASSIGNED VALUE    ###############
a=5
b=6
print(a,b,a+b)
