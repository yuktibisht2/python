a=[ 2,4,78,99]
a.sort()               #will sort the list
print(a)

a=[ 2,4,78,99]
a.reverse()            #will reverse the list
print(a)

a=[ 2,4,78,99]
a.append(8)            #will add input no at the end
print(a)

a=[ 2,4,78,99]
a.insert(0,6)          #will insert 2nd position no(6) at 1st no index(0)
print(a)

a=[ 2,4,78,99]
a.pop(2)              #will remove element at index 2 and return its value
print(a)

a=[ 2,4,78,99]
a.remove(4)           #will remove 4 from the list
print(a)

