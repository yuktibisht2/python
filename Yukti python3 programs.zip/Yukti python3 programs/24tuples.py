# d/f b/w list and tuple is we can update or change lists but
# we cannot change or update tuple 

# creating a tuple using ()
t = (1, 2, 3, 4, 5) 
print(t)



t1 = ()                                  #empty tuple
print(t1)
 
t1=(1,)                                  #tuple with single element neends a comma
print(t1)

t1=(1)    
print(t1)               #wrong way to print a single element tuple i.e. without comma

# printing the elements of tuple
t = (1, 2, 3, 4, 5) 
print(t[4])


#cannot update the value of tuple
# t[0]=22  #throws an error
