#########################GIVING VALUES TO VARIABLES####################################################
a="yukti"
b=18
c=99.5
d=True
e=None
###################PRINTING THE VARIABLES############################
print(a)
print(b)
print(c)
print(d)
print(e)
##################PRINTING THE TYPE OF VARIABLES#############################
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
