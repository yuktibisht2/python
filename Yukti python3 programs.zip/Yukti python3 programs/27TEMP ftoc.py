a=float(input("enter temperature:"))
b=((9*a)/5+32)
print(b)


