a=34
b=80
c=(a>b)
d=(b>a)
print("GREATEST AMONG TWO: ",a,b)
print("34>80",c)
print("80>34",d)
