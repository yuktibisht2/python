''' triple quote will not be considered as comments inside print,it is used to span para which consists of more than one line'''
#this is also considered as comment


print('''
TWINKLE ,TWINKLE , LITTLE STAR,
HOW I WONDER WHAT YOU ARE!
UP ABOVE THE WORLD SO HIGH,
LIKE A DIAMOND IN THE SKY!
''')