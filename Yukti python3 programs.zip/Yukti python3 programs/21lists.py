#  CREATE A LIST USING[]
a=[1,2,3,4,5,6,7,8,9]
print(a)

# ACCESS USING INDEX AS A[0],A[1], A[2]..
print(a[2])

# CHANGE THE VALUE OF LIST USING
a[0]="y"
print(a)

# WE CAN CREATE A LIST WITH ITEMS OF DIFFERENT TYPES
b=['YUKTI', 23, 2002, 'APRIL']
print(b)

#  ACCESS USING INDEX AS B[0], B[1], B[2]..
print(b[3])

# CHANGE THE VALUE OF LIST USING 
b[1]= 28
print(b)